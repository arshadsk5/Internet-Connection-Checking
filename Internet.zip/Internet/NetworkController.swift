//
//  NetworkController.swift
//  FiveClaps
//
//  Created by Manoj MacMini12 on 06/11/15.
//  Copyright © 2015 Manoj MacMini12. All rights reserved.
//

import UIKit

private let _sharedNetworkController = NetworkController()
let kNetworkController = NetworkController.sharedInstance

class NetworkController: NSObject {
  
  let reachability: Reachability = Reachability.forInternetConnection()
  var hasInternetConnection: Bool = false
  
  // MARK: Singleton
  /* init */
  override init() {
    super.init()
    /* <#comment#> */
    startUp()
  }
  
  /* shared instance */
  class var sharedInstance: NetworkController {
    return _sharedNetworkController
  }
  
  func checkNetworkStatus() -> Bool {
    let networkStatus: NetworkStatus = reachability.currentReachabilityStatus()
    hasInternetConnection = (networkStatus != NetworkStatus.NotReachable)
    if !hasInternetConnection {
      UIApplication.shared.endIgnoringInteractionEvents()
      Utilities.showToastWithErrorMessage(message: "INTERNET_CONNECTION_OFF")
      // Utilities.showToastWithErrorMessage(message: CCFD.getLocaliseString(strKey: "INTERNET_CONNECTION_OFF"))
      return false
    }
    
    return true
  }
  
  // MARK: Handle network status
  func networkStatusDidChange(notification: NSNotification?) {
    let networkStatus: NetworkStatus = reachability.currentReachabilityStatus()
    hasInternetConnection = (networkStatus != NetworkStatus.NotReachable)
    
    if !hasInternetConnection {
      Utilities.showToastWithErrorMessage(message: "INTERNET_CONNECTION_OFF")
      //  Utilities.showToastWithErrorMessage(message: CCFD.getLocaliseString(strKey: "INTERNET_CONNECTION_OFF"))
    }
    else{
      Utilities.showToastWithErrorMessage(message: "INTERNET_CONNECTION_ON")
      //  Utilities.showToastWithErrorMessage(message: CCFD.getLocaliseString(strKey: "INTERNET_CONNECTION_ON"))
    }
  }
  
  // MARK: Functions
  
  /* call this once at init */
  func startUp() {
    
    NotificationCenter.default.addObserver(self, selector: #selector(NetworkController.networkStatusDidChange(notification:)), name: NSNotification.Name.reachabilityChanged, object: nil)
    reachability.startNotifier()
  }
}
